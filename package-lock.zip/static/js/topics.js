function lloading(){
    document.querySelector("html").classList.add("darkenPage");
    document.getElementById('spinner').style.zIndex = '1000000'
}
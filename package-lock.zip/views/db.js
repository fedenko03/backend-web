db.mode1.insertMany([
    {
        title: 'Miyagi & Эндшпиль feat. Рем Дигга - I Got Love',
        link: 'https://www.youtube.com/watch?v=nidQCt_HEsY',
        likes: 0
    },
    {
        title: 'Rauf & Faik — детство',
        link: 'https://www.youtube.com/watch?v=m-el0pQLQE4',
        likes: 0
    },
    {
        title: 'Артур Пирожков "Чика"',
        link: 'https://www.youtube.com/watch?v=LOHDnKI1U8A',
        likes: 0
    },
    {
        title: '#2Маши "МАМА, Я ТАНЦУЮ "',
        link: 'https://www.youtube.com/watch?v=jezU0MUixaY',
        likes: 0
    },
    {
        title: 'Dabro - Юность',
        link: 'https://www.youtube.com/watch?v=aqsgyOhrRMY',
        likes: 0
    },
    {
        title: 'ESTRADARADA - Вите Надо Выйти',
        link: 'https://www.youtube.com/watch?v=HO6ebtWczX8',
        likes: 0
    }
])
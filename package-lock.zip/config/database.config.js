module.exports = {
    url:'mongodb+srv://admin-Zhandos:Qwerty12345@cluster0.vh9zg.mongodb.net/web-backend'
}